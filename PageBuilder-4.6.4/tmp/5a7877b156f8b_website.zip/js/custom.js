

window.addEventListener('load', function() {
	$('body').delegate('.inputfile', 'change', customFileField);
});
